print("""
   ___ 
  {o,o}    Diese Aufgabe
  |)__)    erfordert keinen
  -"-"-    Code. Huuuhhhuuuu.
""")
